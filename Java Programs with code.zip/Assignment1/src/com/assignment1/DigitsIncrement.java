package com.assignment1;

public class DigitsIncrement {

	public String digitIncrement(String str){

		String strIntial=str.substring(0, str.length()-3);
		String strDigit=str.substring(str.length()-3, str.length());

		int number=Integer.valueOf(strDigit);

		if(number==999)
			number=000;
		else number =number+1;

		return strIntial.concat(String.valueOf(String.format("%03d", number)));
	}

	public static void main(String args[]){
		String str="WK17H999";
		DigitsIncrement ob=new DigitsIncrement();
		String strChanged=ob.digitIncrement(str);
		
		System.out.println("Changed String with Digits Incremented :"+ strChanged);
	}
}
