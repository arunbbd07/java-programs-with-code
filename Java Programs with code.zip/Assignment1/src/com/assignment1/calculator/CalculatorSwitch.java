package com.assignment1.calculator;

public class CalculatorSwitch implements Calculator{
	@Override
	public double calculate(double firstNumber,double secondNumber,char operator)
	{
		System.out.println("This is Calculator using switch statement!!!");
		double result=0.0;

		switch(operator){
		case '+': result=firstNumber+secondNumber;
		break;
		case '-': result=firstNumber-secondNumber;
		break;
		case '*': result=firstNumber*secondNumber;
		break;
		case '/': result=firstNumber/secondNumber;
		break;
		case '%': result=firstNumber%secondNumber;
		break;
		default : System.out.println("No Operations found!!!");
		}

		return result;
	}
}
