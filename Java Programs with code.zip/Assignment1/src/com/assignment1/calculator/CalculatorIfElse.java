package com.assignment1.calculator;

public class CalculatorIfElse implements Calculator {
	@Override
	public double calculate(double firstNumber,double secondNumber,char operator)
	{
		System.out.println("This is Calculator using if-else statement!!!");
		double result=0.0;

		if(operator=='+')
			result=firstNumber+secondNumber;
		else if(operator=='-')
			result=firstNumber-secondNumber;
		else if(operator=='*')
			result=firstNumber*secondNumber;
		else if(operator=='/')
			result=firstNumber/secondNumber;
		else if(operator=='%')
			result=firstNumber%secondNumber;
		else 
			System.out.println("No Operations found!!!");

		return result;
	}
}
