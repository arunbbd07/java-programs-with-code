package com.assignment1.calculator;

import java.util.Scanner;

public interface Calculator {

	 public double calculate(double firstNumber,double secondNumber,char operator);

}
