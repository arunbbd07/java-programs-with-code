package com.assignment1.calculator;

import java.util.Scanner;

public class CalculatorMain {

	public static void main(String args[]) {
		
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the first number :");
	double firstNumber=sc.nextDouble();
	System.out.println("Enter the second number :");
	double secondNumber=sc.nextDouble();
	System.out.print("Enter an operator (+, -, *, /,%): ");
    char operator = sc.next().charAt(0);
	
	// calculator using swtich
    Calculator calSwitch=new CalculatorSwitch();
	double result1=calSwitch.calculate(firstNumber,secondNumber,operator);
	
	System.out.println("The result of the operation using switch statement is "+ result1);
	
	//calculator using nested if-else
	Calculator calIfElse=new CalculatorIfElse();
	double result2=calIfElse.calculate(firstNumber,secondNumber,operator);
	
	System.out.println("The result of the operation using if-else statement is "+ result2);
	
	}
	

}
