package com.assignment1;

public class OddEvenNumbers {

	public void oddEvenNumber(int x){

		if(x%2==0) 
			System.out.println(x+ " : Even Number!!!");
		else 
			System.out.println(x+ " : Odd Number!!!");
	}

	public static void main(String args[]){
		OddEvenNumbers ob=new OddEvenNumbers();
		int number=132;
		ob.oddEvenNumber(number);

		number=99;
		ob.oddEvenNumber(number);

	}
}
