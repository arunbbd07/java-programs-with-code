package com.assignment1;

public class LargestNumber {

	public int largestNumber(int a,int b,int c){ 
		return (a>b)?((a>c)?a:c) :((b>c)?b:c);
	}
	
	public static void main(String args[]){
		int a=99,b=475,c=771;
		LargestNumber ob=new LargestNumber();
		int largest=ob.largestNumber(a,b,c);
		
		System.out.println("Largest Number : "+largest);
	}
}
