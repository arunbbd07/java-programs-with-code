package com.assignment1;

public  class FinalDemonstrationClass { //this class cannot be inherited - we can although create and object and refer its methods

	public final int i=10;

	public final void displayData()  // this method cannot be overridden
	{
		// i=20; -> if we trying changing the value of i here, it will show error as it is declared final

		System.out.println("The value of i : "+ i);//output will be 10
	}

	public static void main(String args[])
	{
		FinalDemonstrationClass ob=new FinalDemonstrationClass();
		ob.displayData();
	}

}
