package com.assignment1;

public class SumIntegerArray {

	
	public int sumIntegarArray(int[] a){
		int sum=0;
		for(int i=0;i<a.length;i++)
			sum+=a[i];
		
		return sum;
	}
	
	public static void main(String args[]){
		int[] arr= {4,2,32,55,12,98,23,11};
		SumIntegerArray ob=new SumIntegerArray();
		int sum=ob.sumIntegarArray(arr);
		
		System.out.println("Sum of Integer Array : "+sum);
	}
}
