package com.assignment1;

public class RemoveSpaceString {

	public String removeSpaceString(String str){
		StringBuffer strBuff=new StringBuffer();

		for(int i=0;i<str.length();i++){
			if(str.charAt(i)!=' ')
				strBuff.append(str.charAt(i));
		}

		return strBuff.toString();
	}

	public static void main(String args[]){
		RemoveSpaceString ob=new RemoveSpaceString();
		String str="    A utoma tion Tes tin  g   ";
		String strSpaceRmv=ob.removeSpaceString(str);

		System.out.println("The String After removing space :\n "+strSpaceRmv);
	}
}
