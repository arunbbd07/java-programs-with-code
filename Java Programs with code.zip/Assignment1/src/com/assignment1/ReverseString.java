package com.assignment1;

public class ReverseString {

public String reverseString(String str){
		char[] ch=str.toCharArray();
		for(int i=str.length()-1,j=0;j<=i;i--,j++){
			char temp=ch[i];
			ch[i]=ch[j];
			ch[j]=temp;	
		}
		String revStr=String.valueOf(ch);
		return revStr;
}
	
public static void main(String args[]){
		ReverseString rev=new ReverseString();
		String str="Automation Testing";
		String revStr=rev.reverseString(str);
		System.out.println("The String After Reversing : "+revStr);
	}
}
